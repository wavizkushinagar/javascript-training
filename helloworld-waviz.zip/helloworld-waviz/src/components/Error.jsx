import React from "react";

const Error = () => {
    return (
<>
    <h1>opss!! Error page</h1>
</>

    )
};
export default Error;